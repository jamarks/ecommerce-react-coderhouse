import React from 'react'


export default ()=>{
    return (
        <> 
        
            <nav id='footer' className=" navbar-light bg-light">
                <div className='container'>
                    <div className='row'>
                        <div className='col-6'>
                        Dev by <a target='_blank' href='https://twitter.com/javierwasserman'>jamarks</a> | Javier Wasserman<br/>
                        Para CoderHouse, con amor
                        </div>
                        <div className='col'>
                        Footer<br/>
                        Footer
                        </div>
                        <div className='col'>
                        Footer<br/>
                        Footer
                        </div>
                    </div>
                </div>
            </nav>
            
        
         </>
    )
}