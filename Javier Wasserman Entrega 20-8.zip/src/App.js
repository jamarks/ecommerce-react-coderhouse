import React from 'react';
import logo from './logo.svg';
import './App.css';

import NavBar from './components/navBar/NavBar';
import Home from './components/home/home';


const App = () => {
  return (
    <>
        <NavBar/>
        <Home>Javier</Home>
        
   </>
  )
}


export default App;
