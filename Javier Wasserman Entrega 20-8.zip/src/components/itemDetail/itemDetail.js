// muestra el item
import React from 'react';
import ItemCount from '../itemCount/itemCount';

const ItemDetail = (product) => {
        product = product.product[0] // 
        console.log(product);
         return (
            <div class="row">
                <div class="col">
                    <h1>{product.name}</h1>
                    Precio: $<span className='price'>{product.price}</span><br/>
                    <div className='row'>
                        <div className='col-3'>
                            <ItemCount min={1} max={product.stock}></ItemCount>
                        </div>
                        <div className='col-3'>
                            <button type="button" className="btn btn-primary">Comprar</button>
                        </div>
                    </div>
                    <br/><br/>
                    <b>Sobre {product.name}</b>
                    <br/>
                    <p className='description'>{product.description}</p>
                </div>
                <div class="col-6">
                    <img src={product.img} width='100%'></img>
                </div>
            </div>
        )

}



export default ItemDetail;
