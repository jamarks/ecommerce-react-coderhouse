// muestra el item
import React from 'react';
import ItemCount from '../itemCount/itemCount';

const Item = (product) => {
        product = product.product // 
         return (
            <div className='col-3 product'>
                <h3>{product.name}</h3>
                <img src={product.img} width='100%'></img>
                <p className='description'>{product.description}</p>
                Precio: $<span className='price'>{product.price}</span><br/>
                <ItemCount min={1} max={product.stock}></ItemCount>
            </div>
        )

}



export default Item;
