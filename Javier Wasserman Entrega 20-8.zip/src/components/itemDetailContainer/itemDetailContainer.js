import React, { useState, useEffect} from 'react';
import ItemDetail from '../itemDetail/itemDetail'

function getFromRemote() {

    const var1 = {id:1,name:'Remera Blanca XS',price:19.90,stock:30,img:'https://www.chloe.com/product_image/12452284ue/f/w1370.jpg',description:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis arcu mauris, condimentum vitae pharetra id, dignissim at nisi. Maecenas auctor tortor mattis urna bibendum suscipit. Mauris hendrerit ac augue iaculis viverra. Vivamus felis sem, mollis eu dolor eu, ullamcorper faucibus ligula. Duis aliquet, lorem quis tempus vestibulum, ante magna ultrices purus, quis suscipit metus sem vitae enim. Suspendisse lacus tellus, condimentum eu libero vitae, pretium dapibus quam. Curabitur tincidunt aliquam massa ut malesuada. Praesent pharetra enim venenatis lacus feugiat, mattis gravida arcu interdum. Nullam in vestibulum lectus, ac consectetur elit. Ut sit amet sapien quam. Aenean luctus massa tristique, gravida purus vitae, viverra mauris. Ut volutpat, dui eu tincidunt condimentum, ex erat sagittis enim, non semper magna dui quis dolor. Duis sodales lorem ut varius fringilla. Nulla efficitur turpis lacinia molestie condimentum.',};
    
    return new Promise((res,rej)=>{
        setTimeout(() => res([var1]), 1000);
    });

}

function ItemDetailContainer(props) {

    const [products,setProducts] = useState([]);
    const [loading,setLoading] = useState(true);

    useEffect(() => {
        getFromRemote().then(res => {
            //console.log('Loading : ' + loading);
            setProducts(res); 
            setLoading(false); 
            //console.log('Loading : ' + loading);
        });
      }, []);
    
    
    
    return(
        
        <div className='container' style={{paddingTop:20}}>
           {loading?(
               <div className='row justify-content-center'>
               
                    <div className="spinner-grow text-warning" role="status">
                        <span className="sr-only">Loading...</span>
                    </div>  
               </div>
           ):(
                <>
                    <span>Productos | Detalle de producto </span>
                    <ItemDetail product={products}></ItemDetail>
                </>
           )} 
        </div>
        
    )
}
export default ItemDetailContainer;