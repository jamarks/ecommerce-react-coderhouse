import React from 'react'

const menu = () =>{
    return(
        
        <ul className="navbar-nav">
                <li className="nav-item active">
                    <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a>
                </li>
                <li className="nav-item">
                    <a className="nav-link" href="#">Destacados</a>
                </li>
                <li className="nav-item">
                    <a className="nav-link" href="#">Ofertas</a>
                </li>
                <li className="nav-item">
                    <a className="nav-link" href="#">Mi Cuenta</a>
                </li>
            </ul>
    
    )
}
export default menu;