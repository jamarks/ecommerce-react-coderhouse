import React from 'react';
import ItemDetailContainter from '../itemDetailContainer/itemDetailContainer'
import ItemListCointainer from '../itemListContainer/itemListContainer';

function Home(props) {

    //Home - >itemListContainter > itemList > ítem
    //Home - >itemDetailContainter >itemDetail
    
    return(
            <>
            <div className='container' style={{paddingTop:20}}>
                Home. Hola {props.children} 
            </div>
            <div className='container' style={{paddingTop:20}}>
                <div className='row'>
                    <div className="col">
                        <b>ItemListContainter</b>
                    </div>
                </div>
            </div>
            <ItemListCointainer/>
            
            <div className='container' style={{paddingTop:20}}>
                <div className='row'>
                    <div className="col">
                        <b>ItemDetailContainter</b>
                    </div>
                </div>
            </div>
            <ItemDetailContainter/>
        </>
    
    )
}
export default Home;