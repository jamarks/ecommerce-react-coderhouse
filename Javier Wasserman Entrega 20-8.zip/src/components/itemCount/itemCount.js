import React, { useState, useEffect} from 'react';

function ItemCount(props) {
    
    const [cantidad, setCount] = useState(props.min);

    useEffect(()=>{
        if(cantidad!==props.min)
           // console.log('Se modifico' + cantidad);
        
            return()=>{
          //console.log('limpio')
        }

      },[cantidad])

      useEffect(()=>{
          //  console.log('montado');
        
            return()=>{
          //console.log('limpio montaje')
        }

      },[])

    function dedact(min){
        if(cantidad>min){
            setCount(parseInt(cantidad)-1);
        }
        else{}
    }
    function sum(max){
        
        if(cantidad<max){
            setCount(parseInt(cantidad)+1);
        }
        else{}

    }
    
    return(

            <div className='itemCounter'>
                <button id='dedact' name='dedact' onClick={()=>dedact(props.min)} disabled={cantidad===props.min}> - </button>
                <span>{cantidad}</span>
                <button id='sum' name='sum' onClick={()=>sum(props.max)} disabled={cantidad===props.max}> + </button>
            </div>
        
    )
}
export default ItemCount;
